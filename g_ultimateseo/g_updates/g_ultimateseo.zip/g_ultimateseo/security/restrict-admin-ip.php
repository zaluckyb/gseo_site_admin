<?php
if (!defined('ABSPATH')) exit;

// $options = get_option('gseo_security_settings', []);
// if (!empty($options['limit_admin_ip'])) {
//     function gseo_restrict_admin_area() {
//         $allowed_ips = ['123.456.78.90']; // Replace with your real IP(s)
//         if (is_admin() && !in_array($_SERVER['REMOTE_ADDR'], $allowed_ips)) {
//             wp_die('Admin access restricted.');
//         }
//     }
//     add_action('admin_init', 'gseo_restrict_admin_area');
// }
